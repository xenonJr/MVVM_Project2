package com.example.midmvvm.viewmodels;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.midmvvm.models.NicePlaces;
import com.example.midmvvm.repositories.NicePlaceRepository;

import java.util.List;

public class MainActivityViewModels extends ViewModel {
    private MutableLiveData<List<NicePlaces>> mNicePlaces;
    private NicePlaceRepository nicePlaceRepository;

    public void init(){
        if(mNicePlaces!=null){
            return;
        }
        nicePlaceRepository = NicePlaceRepository.getInstance();
        mNicePlaces = nicePlaceRepository.getNicePlacesRep();
    }

    public MutableLiveData<List<NicePlaces>> getNicePlaces(){

        return mNicePlaces;
    }
}
