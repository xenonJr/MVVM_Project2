package com.example.midmvvm.models;

public class NicePlaces {
    public String name;
    public String imgUrl;

    public NicePlaces(String imgUrl,String name){
        this.name = name;
        this.imgUrl = imgUrl;
    }

    NicePlaces(){

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
