package com.example.midmvvm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.midmvvm.adapters.ItemAdapter;
import com.example.midmvvm.models.NicePlaces;
import com.example.midmvvm.viewmodels.MainActivityViewModels;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ImageView placeImage;
    TextView placeName;
    ItemAdapter itemAdapter;
    RecyclerView recyclerView;
    MainActivityViewModels mainActivityViewModels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        placeImage = findViewById(R.id.place_image);
        placeName = findViewById(R.id.name);
        recyclerView = findViewById(R.id.recycleView);
        mainActivityViewModels = new ViewModelProvider(this).get(MainActivityViewModels.class);

        mainActivityViewModels.init();
        mainActivityViewModels.getNicePlaces().observe(this, new Observer<List<NicePlaces>>() {
            @Override
            public void onChanged(List<NicePlaces> nicePlaces) {
                itemAdapter.notifyDataSetChanged();
            }
        });


        initRecyclerView();


    }

    private void initRecyclerView() {
        itemAdapter = new ItemAdapter(mainActivityViewModels.getNicePlaces().getValue(), this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(itemAdapter);
    }
}