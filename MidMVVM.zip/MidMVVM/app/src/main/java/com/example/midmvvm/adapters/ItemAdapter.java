package com.example.midmvvm.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.midmvvm.R;
import com.example.midmvvm.models.NicePlaces;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    List<NicePlaces> itemList;
    Context context;

    public ItemAdapter(List<NicePlaces> itemList, Context context) {
        this.itemList = itemList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.layout_niceplaces, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
//        Glide.with(context)
//                .load(itemList.get(position).getImgUrl())
//                .placeholder(R.drawable.ic_launcher_background)
//                .into(holder.NicePlacesImage);

//        Glide.with(context).load(itemList.get(position).getImgUrl()).placeholder(R.drawable.ic_launcher_background)
//                        .into(holder.NicePlacesImage);

        RequestOptions defaultOptions = new RequestOptions()
                .centerCrop()
                .error(R.drawable.ic_launcher_background);

        Log.d("link",itemList.get(position).imgUrl);
        Glide.with(context)
                .setDefaultRequestOptions(defaultOptions)
                .load(itemList.get(position).imgUrl)
                .into(((ViewHolder)holder).NicePlacesImage);

        holder.name.setText(itemList.get(position).getName());

    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView NicePlacesImage;
        TextView name;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
            NicePlacesImage = itemView.findViewById(R.id.place_image);
        }
    }
}
